import setuptools

setuptools.setup(
    name="TPs Python B3C2",
    version="1.0",
    author="Vincent Marignier",
    author_email="vincent.marignier@epsi.fr",
    description="TPs de python",
    packages=setuptools.find_packages(),
    python_requires = '>= 3.7'
)